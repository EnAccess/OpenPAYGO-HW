#ifndef restricted_digit_set_mode_h
#define restricted_digit_set_mode_h

#include <stdio.h>
#include <stdbool.h>

uint32_t ConvertFromFourDigitToken(uint64_t FourDigitToken);

#endif
